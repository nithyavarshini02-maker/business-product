import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Users, BookOpen, ClipboardCheck, TrendingUp, CalendarDays } from 'lucide-react';
import { format } from 'date-fns';

const StatCard = ({ icon: Icon, label, value, accent }) => (
  <div className="bg-white rounded-xl border border-slate-200 p-5">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm text-slate-500">{label}</p>
        <p className="text-2xl font-semibold text-slate-900 mt-1">{value}</p>
      </div>
      <div className={`w-11 h-11 rounded-lg flex items-center justify-center ${accent}`}>
        <Icon className="w-5 h-5" />
      </div>
    </div>
  </div>
);

export default function Dashboard() {
  const [stats, setStats] = useState({ students: 0, subjects: 0, records: 0, present: 0 });
  const [recent, setRecent] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [students, subjects, records, present, recentPage] = await Promise.all([
          base44.entities.Student.count(),
          base44.entities.Subject.count(),
          base44.entities.AttendanceRecord.count(),
          base44.entities.AttendanceRecord.count({ status: 'present' }),
          base44.entities.AttendanceRecord.filter({}, { sort: '-created_date', limit: 6 }),
        ]);
        setStats({ students, subjects, records, present });
        setRecent(recentPage.items);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const rate = stats.records ? Math.round((stats.present / stats.records) * 100) : 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">Dashboard</h1>
        <p className="text-slate-500 text-sm mt-1">Overview of your attendance system</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Users} label="Total Students" value={stats.students} accent="bg-indigo-50 text-indigo-600" />
        <StatCard icon={BookOpen} label="Subjects" value={stats.subjects} accent="bg-emerald-50 text-emerald-600" />
        <StatCard icon={ClipboardCheck} label="Records Logged" value={stats.records} accent="bg-amber-50 text-amber-600" />
        <StatCard icon={TrendingUp} label="Attendance Rate" value={`${rate}%`} accent="bg-rose-50 text-rose-600" />
      </div>

      <div className="bg-white rounded-xl border border-slate-200">
        <div className="p-5 border-b border-slate-200">
          <h2 className="font-semibold text-slate-900 flex items-center gap-2">
            <CalendarDays className="w-4 h-4 text-slate-400" /> Recent Attendance
          </h2>
        </div>
        <div className="divide-y divide-slate-100">
          {loading ? (
            <p className="p-5 text-sm text-slate-400">Loading…</p>
          ) : recent.length === 0 ? (
            <p className="p-5 text-sm text-slate-400">No attendance records yet. Mark attendance to get started.</p>
          ) : (
            recent.map((r) => (
              <div key={r.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-900">{r.student_name}</p>
                  <p className="text-xs text-slate-500">{r.subject_name} · {format(new Date(r.date), 'MMM d, yyyy')}</p>
                </div>
                <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${r.status === 'present' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'}`}>
                  {r.status === 'present' ? 'Present' : 'Absent'}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}