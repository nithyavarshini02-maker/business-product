import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import { FileBarChart, Download, TrendingUp } from 'lucide-react';

export default function Reports() {
  const [subjects, setSubjects] = useState([]);
  const [subjectId, setSubjectId] = useState('all');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [generated, setGenerated] = useState(false);
  const [overall, setOverall] = useState({ total: 0, present: 0 });

  useEffect(() => {
    (async () => {
      const res = await base44.entities.Subject.filter({}, { sort: 'name', limit: 100 });
      setSubjects(res.items);
    })();
  }, []);

  const generate = async () => {
    setLoading(true);
    setGenerated(false);
    const query = {};
    if (subjectId !== 'all') query.subject_id = subjectId;
    if (from || to) {
      query.date = {};
      if (from) query.date.$gte = from;
      if (to) query.date.$lte = to;
    }

    const [studentsRes, totalsAgg, presentsAgg] = await Promise.all([
      base44.entities.Student.filter({}, { sort: 'roll_number', limit: 300 }),
      base44.entities.AttendanceRecord.aggregate({ query, groupBy: 'student_id', count: true }),
      base44.entities.AttendanceRecord.aggregate({ query: { ...query, status: 'present' }, groupBy: 'student_id', count: true }),
    ]);

    const totalMap = {};
    totalsAgg.rows.forEach((r) => { totalMap[r.student_id] = r.count; });
    const presentMap = {};
    presentsAgg.rows.forEach((r) => { presentMap[r.student_id] = r.count; });

    const merged = studentsRes.items
      .map((s) => {
        const total = totalMap[s.id] || 0;
        const present = presentMap[s.id] || 0;
        const pct = total ? Math.round((present / total) * 100) : 0;
        return { ...s, total, present, pct };
      })
      .filter((r) => r.total > 0)
      .sort((a, b) => b.pct - a.pct);

    setRows(merged);
    setOverall({
      total: merged.reduce((a, r) => a + r.total, 0),
      present: merged.reduce((a, r) => a + r.present, 0),
    });
    setLoading(false);
    setGenerated(true);
  };

  const overallRate = overall.total ? Math.round((overall.present / overall.total) * 100) : 0;

  const exportCsv = () => {
    const header = 'Name,Roll Number,Grade,Classes Total,Present,Percentage\n';
    const body = rows.map((r) => `${r.name},${r.roll_number},${r.grade || ''},${r.total},${r.present},${r.pct}%`).join('\n');
    const blob = new Blob([header + body], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'attendance-report.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">Reports</h1>
        <p className="text-slate-500 text-sm mt-1">Generate attendance reports by subject and date range</p>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 items-end">
          <div className="space-y-1.5">
            <Label>Subject</Label>
            <Select value={subjectId} onValueChange={setSubjectId}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Subjects</SelectItem>
                {subjects.map((s) => (
                  <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>From</Label>
            <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>To</Label>
            <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
          </div>
          <Button onClick={generate} disabled={loading} className="bg-indigo-600 hover:bg-indigo-700">
            <FileBarChart className="w-4 h-4 mr-1.5" /> {loading ? 'Generating…' : 'Generate'}
          </Button>
        </div>
      </div>

      {generated && (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white rounded-xl border border-slate-200 p-5">
              <p className="text-sm text-slate-500">Students in Report</p>
              <p className="text-2xl font-semibold text-slate-900 mt-1">{rows.length}</p>
            </div>
            <div className="bg-white rounded-xl border border-slate-200 p-5">
              <p className="text-sm text-slate-500">Total Entries</p>
              <p className="text-2xl font-semibold text-slate-900 mt-1">{overall.total}</p>
            </div>
            <div className="bg-white rounded-xl border border-slate-200 p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">Overall Rate</p>
                  <p className="text-2xl font-semibold text-slate-900 mt-1">{overallRate}%</p>
                </div>
                <div className="w-11 h-11 rounded-lg bg-rose-50 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-rose-600" />
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between">
              <h2 className="font-semibold text-slate-900 text-sm">Per-Student Attendance</h2>
              <Button variant="outline" size="sm" onClick={exportCsv} disabled={rows.length === 0}>
                <Download className="w-4 h-4 mr-1.5" /> Export CSV
              </Button>
            </div>
            {rows.length === 0 ? (
              <p className="p-5 text-sm text-slate-400">No attendance data for the selected filters.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 text-slate-500 text-left">
                    <tr>
                      <th className="px-5 py-3 font-medium">Roll No</th>
                      <th className="px-5 py-3 font-medium">Name</th>
                      <th className="px-5 py-3 font-medium">Grade</th>
                      <th className="px-5 py-3 font-medium">Present</th>
                      <th className="px-5 py-3 font-medium">Total</th>
                      <th className="px-5 py-3 font-medium">Percentage</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {rows.map((r) => (
                      <tr key={r.id} className="hover:bg-slate-50">
                        <td className="px-5 py-3 text-slate-600 font-medium">{r.roll_number}</td>
                        <td className="px-5 py-3 text-slate-900 font-medium">{r.name}</td>
                        <td className="px-5 py-3 text-slate-500">{r.grade || '—'}</td>
                        <td className="px-5 py-3 text-emerald-600 font-medium">{r.present}</td>
                        <td className="px-5 py-3 text-slate-500">{r.total}</td>
                        <td className="px-5 py-3">
                          <div className="flex items-center gap-2">
                            <div className="w-24 h-2 bg-slate-100 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full ${r.pct >= 75 ? 'bg-emerald-500' : r.pct >= 50 ? 'bg-amber-500' : 'bg-rose-500'}`}
                                style={{ width: `${r.pct}%` }}
                              />
                            </div>
                            <span className="text-slate-700 font-medium text-xs w-9">{r.pct}%</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}