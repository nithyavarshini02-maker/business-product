import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { formatDistanceToNow } from 'date-fns';
import { Github, GitCommitHorizontal, Star, Lock, Globe, ExternalLink } from 'lucide-react';

export default function GithubView() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const res = await base44.functions.invoke('githubOverview', {});
        setData(res.data);
      } catch (e) {
        setError(e?.response?.data?.error || e.message || 'Failed to load GitHub data');
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">GitHub</h1>
        <p className="text-slate-500 text-sm mt-1">Your repositories and recent commits</p>
      </div>

      {loading && <p className="text-sm text-slate-400">Loading GitHub data…</p>}

      {error && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 text-center">
          <Github className="w-10 h-10 text-slate-300 mx-auto mb-2" />
          <p className="text-sm text-slate-500">{error}</p>
        </div>
      )}

      {data && (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {data.repos.map((r) => (
              <a
                key={r.name}
                href={r.url}
                target="_blank"
                rel="noreferrer"
                className="bg-white rounded-xl border border-slate-200 p-5 hover:border-indigo-300 transition"
              >
                <div className="flex items-start justify-between">
                  <Github className="w-5 h-5 text-slate-700" />
                  {r.isPrivate ? <Lock className="w-3.5 h-3.5 text-slate-400" /> : <Globe className="w-3.5 h-3.5 text-slate-400" />}
                </div>
                <p className="font-medium text-slate-900 mt-3 text-sm break-all">{r.name}</p>
                {r.description && <p className="text-xs text-slate-500 mt-1 line-clamp-2">{r.description}</p>}
                <div className="flex items-center gap-3 mt-3 text-xs text-slate-500">
                  {r.language && (
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-indigo-500" /> {r.language}
                    </span>
                  )}
                  <span className="flex items-center gap-1"><Star className="w-3.5 h-3.5" /> {r.stars}</span>
                </div>
                <p className="text-xs text-slate-400 mt-2">Updated {formatDistanceToNow(new Date(r.updated_at), { addSuffix: true })}</p>
              </a>
            ))}
          </div>
          {data.repos.length === 0 && (
            <p className="text-sm text-slate-400">No repositories found for the connected account.</p>
          )}

          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200">
              <h2 className="font-semibold text-slate-900 flex items-center gap-2">
                <GitCommitHorizontal className="w-4 h-4 text-slate-400" /> Recent Commits
              </h2>
            </div>
            {data.commits.length === 0 ? (
              <p className="p-5 text-sm text-slate-400">No commits found.</p>
            ) : (
              <div className="divide-y divide-slate-100">
                {data.commits.map((c, i) => (
                  <a key={i} href={c.url} target="_blank" rel="noreferrer" className="p-4 flex items-start justify-between gap-4 hover:bg-slate-50">
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-900 truncate">{c.message}</p>
                      <p className="text-xs text-slate-500 mt-0.5">{c.repo} · {c.author} · {formatDistanceToNow(new Date(c.date), { addSuffix: true })}</p>
                    </div>
                    <ExternalLink className="w-4 h-4 text-slate-300 flex-shrink-0 mt-1" />
                  </a>
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}