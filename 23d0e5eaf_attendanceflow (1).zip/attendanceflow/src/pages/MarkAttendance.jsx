import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { format } from 'date-fns';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import { Check, X, Save, ClipboardCheck, CheckCheck, XCircle } from 'lucide-react';

export default function MarkAttendance() {
  const [subjects, setSubjects] = useState([]);
  const [students, setStudents] = useState([]);
  const [subjectId, setSubjectId] = useState('');
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [attendance, setAttendance] = useState({});
  const [loaded, setLoaded] = useState(false);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    (async () => {
      const res = await base44.entities.Subject.filter({}, { sort: 'name', limit: 100 });
      setSubjects(res.items);
    })();
  }, []);

  const loadRoster = async () => {
    if (!subjectId) return;
    setLoading(true);
    setSaved(false);
    const [studentRes, existing] = await Promise.all([
      base44.entities.Student.filter({}, { sort: 'roll_number', limit: 300 }),
      base44.entities.AttendanceRecord.filter({ subject_id: subjectId, date }, { limit: 300 }),
    ]);
    setStudents(studentRes.items);
    const map = {};
    existing.items.forEach((r) => { map[r.student_id] = r.status; });
    setAttendance(map);
    setLoaded(true);
    setLoading(false);
  };

  const toggle = (id) =>
    setAttendance((a) => ({ ...a, [id]: a[id] === 'present' ? 'absent' : 'present' }));

  const markAll = (status) => {
    const map = {};
    students.forEach((s) => { map[s.id] = status; });
    setAttendance(map);
  };

  const save = async () => {
    setSaving(true);
    try {
      const subject = subjects.find((s) => s.id === subjectId);
      const records = students.map((s) => ({
        record_key: `${subjectId}_${date}_${s.id}`,
        student_id: s.id,
        subject_id: subjectId,
        student_name: s.name,
        subject_name: subject.name,
        date,
        status: attendance[s.id] || 'absent',
      }));
      await base44.entities.AttendanceRecord.upsert(records, { key: 'record_key' });
      setSaved(true);
    } finally {
      setSaving(false);
    }
  };

  const presentCount = students.filter((s) => attendance[s.id] === 'present').length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">Mark Attendance</h1>
        <p className="text-slate-500 text-sm mt-1">Select a subject and date, then toggle each student</p>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
          <div className="space-y-1.5">
            <Label>Subject</Label>
            <Select value={subjectId} onValueChange={(v) => { setSubjectId(v); setLoaded(false); }}>
              <SelectTrigger><SelectValue placeholder="Choose subject" /></SelectTrigger>
              <SelectContent>
                {subjects.map((s) => (
                  <SelectItem key={s.id} value={s.id}>{s.name} ({s.code})</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Date</Label>
            <Input type="date" value={date} onChange={(e) => { setDate(e.target.value); setLoaded(false); }} />
          </div>
          <Button onClick={loadRoster} disabled={!subjectId || loading} className="bg-indigo-600 hover:bg-indigo-700">
            {loading ? 'Loading…' : 'Load Roster'}
          </Button>
        </div>
      </div>

      {loaded && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <ClipboardCheck className="w-5 h-5 text-indigo-600" />
              <div>
                <p className="font-semibold text-slate-900 text-sm">{students.length} students</p>
                <p className="text-xs text-slate-500">{presentCount} present · {students.length - presentCount} absent</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => markAll('present')}>
                <CheckCheck className="w-4 h-4 mr-1.5" /> All Present
              </Button>
              <Button variant="outline" size="sm" onClick={() => markAll('absent')}>
                <XCircle className="w-4 h-4 mr-1.5" /> All Absent
              </Button>
            </div>
          </div>

          {students.length === 0 ? (
            <p className="p-5 text-sm text-slate-400">No students enrolled. Add students first.</p>
          ) : (
            <div className="divide-y divide-slate-100">
              {students.map((s) => {
                const status = attendance[s.id] || 'absent';
                return (
                  <div key={s.id} className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center text-xs font-semibold text-slate-600">
                        {s.roll_number}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-slate-900">{s.name}</p>
                        {s.grade && <p className="text-xs text-slate-500">{s.grade}</p>}
                      </div>
                    </div>
                    <button
                      onClick={() => toggle(s.id)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                        status === 'present'
                          ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                          : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
                      }`}
                    >
                      {status === 'present' ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
                      {status === 'present' ? 'Present' : 'Absent'}
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          <div className="p-4 border-t border-slate-200 flex items-center justify-between">
            {saved ? (
              <p className="text-sm text-emerald-600 font-medium">✓ Attendance saved successfully.</p>
            ) : <span />}
            <Button onClick={save} disabled={saving || students.length === 0} className="bg-indigo-600 hover:bg-indigo-700 ml-auto">
              <Save className="w-4 h-4 mr-1.5" /> {saving ? 'Saving…' : 'Save Attendance'}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}