import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { accessToken } = await base44.asServiceRole.connectors.getConnection('github');
    const headers = {
      Authorization: `Bearer ${accessToken}`,
      Accept: 'application/vnd.github+json',
      'User-Agent': 'AttendPro-App',
    };

    const reposRes = await fetch('https://api.github.com/user/repos?sort=updated&per_page=8', {
      headers,
      signal: AbortSignal.timeout(10000),
    });
    if (!reposRes.ok) {
      const body = await reposRes.text().catch(() => '');
      return Response.json({ error: `GitHub API error ${reposRes.status}: ${body.slice(0, 300)}` }, { status: 502 });
    }
    const repos = await reposRes.json();

    const reposOut = repos.map((r) => ({
      name: r.full_name,
      description: r.description,
      language: r.language,
      stars: r.stargazers_count,
      isPrivate: r.private,
      url: r.html_url,
      updated_at: r.updated_at,
    }));

    const top = repos.slice(0, 5);
    const commitResults = await Promise.allSettled(
      top.map((r) =>
        fetch(`https://api.github.com/repos/${r.full_name}/commits?per_page=5`, {
          headers,
          signal: AbortSignal.timeout(10000),
        }).then((res) => (res.ok ? res.json() : []))
      )
    );

    const commits = commitResults
      .flatMap((result, i) => {
        if (result.status !== 'fulfilled' || !Array.isArray(result.value)) return [];
        const repo = top[i];
        return result.value.map((c) => ({
          repo: repo.full_name,
          message: (c.commit?.message || '').split('\n')[0],
          author: c.commit?.author?.name || '',
          date: c.commit?.author?.date || '',
          url: c.html_url,
        }));
      })
      .sort((a, b) => (b.date || '').localeCompare(a.date || ''))
      .slice(0, 15);

    return Response.json({ repos: reposOut, commits });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}